
package org.xyz.samples.portfolio.service;


public interface TradeService {

	void executeTrade(Trade trade);

}
