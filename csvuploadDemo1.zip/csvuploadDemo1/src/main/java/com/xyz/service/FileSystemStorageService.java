package com.xyz.service;


import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.xyz.exception.StorageException;
import com.xyz.mybatis.domain.Products;
import com.xyz.mybatis.mappers.ProductMapper;

@Service
public class FileSystemStorageService implements StorageService {

    @Autowired
    ProductMapper productMapper;
    
    @Override
    public void store(MultipartFile excelfile) {
		Workbook workbook;
		try {
			 if (excelfile.getOriginalFilename().endsWith("xls")) {
				workbook = new HSSFWorkbook(excelfile.getInputStream());
			  } else if (excelfile.getOriginalFilename().endsWith("xlsx")) {
				workbook = new XSSFWorkbook(excelfile.getInputStream());
			}else {
				throw new StorageException("Received file does not have a standard excel extension.");
			}
			int FIRST_ROW_TO_GET = 2;
			Sheet sheet =workbook.getSheetAt(0);
			for (int i = FIRST_ROW_TO_GET; i < sheet.getLastRowNum(); i++) {
				   Row row = sheet.getRow(i);
				   if (row == null) {
				      // The whole row is blank
				   }
				   else {
					   Products product=new Products();
					   // part num 
					   Cell cell1 = row.getCell(1, Row.CREATE_NULL_AS_BLANK);
					   cell1.setCellType(Cell.CELL_TYPE_STRING);
					   product.setPartNum(cell1.getStringCellValue());
					   //Merch number
					   Cell cell11 = row.getCell(11, Row.CREATE_NULL_AS_BLANK);
					   cell1.setCellType(Cell.CELL_TYPE_STRING);
					   product.setMerchNumber(cell11.getStringCellValue());
					   //Vendor
					   Cell cell2 = row.getCell(2, Row.CREATE_NULL_AS_BLANK);
					   cell1.setCellType(Cell.CELL_TYPE_STRING);
					   product.setVendor(cell2.getStringCellValue());
					   //Supp Part ID
					   Cell cell3 = row.getCell(3, Row.CREATE_NULL_AS_BLANK);
					   cell1.setCellType(Cell.CELL_TYPE_STRING);
					   product.setSuppPartId(cell3.getStringCellValue());
					   //Note- ignore article callum 
					   //Article Description
					   Cell cell5 = row.getCell(5, Row.CREATE_NULL_AS_BLANK);
					   cell5.setCellType(Cell.CELL_TYPE_STRING);
					   product.setArticleDescription(cell5.getStringCellValue());
					   //Contract Number
					   Cell cell6 = row.getCell(6, Row.CREATE_NULL_AS_BLANK);
					   product.setContractNumber((int) cell6.getNumericCellValue());
					   //Cont Line Num
					   Cell cell7 = row.getCell(7, Row.CREATE_NULL_AS_BLANK);
					   product.setContLineNum((int) cell7.getNumericCellValue());
					   //Amount in LC
					   Cell cell8 = row.getCell(8, Row.CREATE_NULL_AS_BLANK);
					   cell8.setCellType(Cell.CELL_TYPE_STRING);
					   String temp=cell8.getStringCellValue();
					   product.setAmountLc(100.00);
					   //Base Unit
					   Cell cell9 = row.getCell(9, Row.CREATE_NULL_AS_BLANK);
					   cell9.setCellType(Cell.CELL_TYPE_STRING);
					   product.setBaseUnit(cell9.getStringCellValue());
					   //Lead Time
					   Cell cell10 = row.getCell(10, Row.CREATE_NULL_AS_BLANK);
					   product.setLeadTime((int) cell10.getNumericCellValue());
					   productMapper.deleteAllProducts();
					   productMapper.insertProduct(product);
					   
				      }
				   }
			
		} catch (IOException e) {
			e.printStackTrace();
			throw new StorageException("Failed to store file ", e);
		}

    }

   
}
