package com.xyz.mybatis.mappers;


import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.xyz.mybatis.domain.Products;
@Repository
@Mapper
public interface ProductMapper {

    @Delete("SELECT  FROM Products")
    void deleteAllProducts();
    
    @Insert("insert into Products(lead_time,base_unit,amount_lc,cont_line_num,contract_number,article_description,supp_part_id,vendor,part_num,merch_number,part_name ) values(#{leadTime},#{baseUnit},#{amountLc},#{contLineNum},#{contractNumber},#{articleDescription},#{suppPartId},#{vendor},#{partNum},#{merchNumber},#{partName})")
    void insertProduct(Products product);
}