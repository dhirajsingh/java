
package com.xyz.mybatis.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
/**
  * @author dhiraj
 */
public class Products implements Serializable {
  
   	private static final long serialVersionUID = 1L;
	private Integer id;
    private String suppPartId;
    private String merchNumber;
    private Integer productPartStatusId;
    private Integer productPartCategoryId;
    private String partName;
    private String partNum;
    private String targetNum;
    private String manufacturerNum;
    private String articleDescription;
    private String bomDescription;
    private BigInteger length;
    private BigInteger height;
    private BigInteger depth;
    private String unitCount;
    private Integer quantityLimit;
    private String vendor;
    private Double amountLc;
    private String imageUrl;
    private String mdseCatgry;
    private Integer leadTime;
    private Integer contractNumber;
    private Integer contLineNum;
    private String baseUnit;
    private String comments;
    private Integer crteById;
    private Date crteTs;
    private Integer updtById;
    private Date updtTs;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSuppPartId() {
		return suppPartId;
	}
	public void setSuppPartId(String suppPartId) {
		this.suppPartId = suppPartId;
	}
	public String getMerchNumber() {
		return merchNumber;
	}
	public void setMerchNumber(String merchNumber) {
		this.merchNumber = merchNumber;
	}
	public Integer getProductPartStatusId() {
		return productPartStatusId;
	}
	public void setProductPartStatusId(Integer productPartStatusId) {
		this.productPartStatusId = productPartStatusId;
	}
	public Integer getProductPartCategoryId() {
		return productPartCategoryId;
	}
	public void setProductPartCategoryId(Integer productPartCategoryId) {
		this.productPartCategoryId = productPartCategoryId;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public String getPartNum() {
		return partNum;
	}
	public void setPartNum(String partNum) {
		this.partNum = partNum;
	}
	public String getTargetNum() {
		return targetNum;
	}
	public void setTargetNum(String targetNum) {
		this.targetNum = targetNum;
	}
	public String getManufacturerNum() {
		return manufacturerNum;
	}
	public void setManufacturerNum(String manufacturerNum) {
		this.manufacturerNum = manufacturerNum;
	}
	public String getArticleDescription() {
		return articleDescription;
	}
	public void setArticleDescription(String articleDescription) {
		this.articleDescription = articleDescription;
	}
	public String getBomDescription() {
		return bomDescription;
	}
	public void setBomDescription(String bomDescription) {
		this.bomDescription = bomDescription;
	}
	public BigInteger getLength() {
		return length;
	}
	public void setLength(BigInteger length) {
		this.length = length;
	}
	public BigInteger getHeight() {
		return height;
	}
	public void setHeight(BigInteger height) {
		this.height = height;
	}
	public BigInteger getDepth() {
		return depth;
	}
	public void setDepth(BigInteger depth) {
		this.depth = depth;
	}
	public String getUnitCount() {
		return unitCount;
	}
	public void setUnitCount(String unitCount) {
		this.unitCount = unitCount;
	}
	public Integer getQuantityLimit() {
		return quantityLimit;
	}
	public void setQuantityLimit(Integer quantityLimit) {
		this.quantityLimit = quantityLimit;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public Double getAmountLc() {
		return amountLc;
	}
	public void setAmountLc(Double amountLc) {
		this.amountLc = amountLc;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getMdseCatgry() {
		return mdseCatgry;
	}
	public void setMdseCatgry(String mdseCatgry) {
		this.mdseCatgry = mdseCatgry;
	}
	public Integer getLeadTime() {
		return leadTime;
	}
	public void setLeadTime(Integer leadTime) {
		this.leadTime = leadTime;
	}
	public Integer getContractNumber() {
		return contractNumber;
	}
	public void setContractNumber(Integer contractNumber) {
		this.contractNumber = contractNumber;
	}
	public Integer getContLineNum() {
		return contLineNum;
	}
	public void setContLineNum(Integer contLineNum) {
		this.contLineNum = contLineNum;
	}
	public String getBaseUnit() {
		return baseUnit;
	}
	public void setBaseUnit(String baseUnit) {
		this.baseUnit = baseUnit;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Integer getCrteById() {
		return crteById;
	}
	public void setCrteById(Integer crteById) {
		this.crteById = crteById;
	}
	public Date getCrteTs() {
		return crteTs;
	}
	public void setCrteTs(Date crteTs) {
		this.crteTs = crteTs;
	}
	public Integer getUpdtById() {
		return updtById;
	}
	public void setUpdtById(Integer updtById) {
		this.updtById = updtById;
	}
	public Date getUpdtTs() {
		return updtTs;
	}
	public void setUpdtTs(Date updtTs) {
		this.updtTs = updtTs;
	}
   
    
}
